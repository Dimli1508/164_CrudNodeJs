
const buffer = Buffer.from("Eko Kurniawan Khannedy");

console.info(buffer);
console.info(buffer.toString());

buffer.reverse();
console.info(buffer.toString());
