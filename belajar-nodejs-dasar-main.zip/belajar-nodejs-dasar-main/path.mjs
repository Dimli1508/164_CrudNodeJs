import path from "path";

const file = "/Users/asroni/contoh.txt";

//const file = "/Users/asroni/Library/CloudStorage/OneDrive-UniversitasMuhammadiyahYogyakarta/Kuliah TI/Genap 2023-2024/PDW/Materi/";

console.info(path.dirname(file));
console.info(path.basename(file));
console.info(path.extname(file));
