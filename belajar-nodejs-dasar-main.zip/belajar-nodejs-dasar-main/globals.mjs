
setTimeout(() => {
    console.info("Hello Globals");
}, 3000);
