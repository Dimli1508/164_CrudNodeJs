
setInterval(() => {
    console.info(`Start time at ${new Date()}`);
}, 1000);
